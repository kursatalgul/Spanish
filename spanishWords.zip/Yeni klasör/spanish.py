from encodings import utf_8
from translate import Translator
import requests
import random
import json
import wget
import os


def ControlJsonWord():
    haveOrnotFile = os.path.exists("text.json")
    #if haveOrnotFile == False:
        #url = "https://raw.githubusercontent.com/words/an-array-of-spanish-words/master/index.json"
        #wget.download(url)
    #else:
        #return 0

def TranslateWord(text):
    translator= Translator(from_lang="spanish",to_lang="turkish")
    translation = translator.translate(text)
    return translation


ControlJsonWord()


if ControlJsonWord() == 0:
    while True:
        with open("text.json", "r" , encoding="utf_8") as file:
            data = json.load(file)
            words = random.choice(data)
            userInput = input(f"'{words}' kelimesinin anlamı ne: ")

            try:
                answer = TranslateWord(words)
                if userInput.upper() == answer.upper():
                    print(f"succesfull '{userInput}' doğru")
                    continue
                else:
                    print(f"'{userInput}' yanlış, doğrusu; '{answer}'")
            except KeyboardInterrupt:
                print("good by")

            finally:
                file.close()

            